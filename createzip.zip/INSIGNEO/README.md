# INSIGNEO-internship-2019---Coronary-resistance
Collaborators: Aldair M Silva (Student/Researcher), Maria-Cruz Villa-Uriol (Project Supervisor), Sheffield Teaching Hospital NHS Foundation Trust (Rebecca Gosling and Prof Julian Gunn), and the Machine Learning group in the Department of Computer Science (Dr Mauricio Alvarez).

This repository is dedicated to the research project on automatic estimation of myocardial resistance.
It will contain the dataset ExCell files, the python code from jupyter notebooks, and relevant documentation of experiments done.
